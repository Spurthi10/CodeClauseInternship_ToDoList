document.addEventListener('DOMContentLoaded', function() {
    const taskInput = document.getElementById('taskInput');
    const addBtn = document.getElementById('addBtn');
    const taskList = document.getElementById('taskList');

    addBtn.addEventListener('click', addTask);

    function addTask() {
        const task = taskInput.value.trim();
        if (task === '') {
            alert('Please enter a task');
            return;
        }

        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <span>${task}</span>
            <div>
                <button onclick="editTask(this)">Edit</button>
                <button onclick="deleteTask(this)">Delete</button>
            </div>
        `;
        taskList.appendChild(listItem);
        taskInput.value = '';
    }
});

function editTask(button) {
    const listItem = button.parentElement.parentElement;
    const task = listItem.querySelector('span').innerText;
    const newTask = prompt('Edit your task:', task);

    if (newTask !== null && newTask.trim() !== '') {
        listItem.querySelector('span').innerText = newTask.trim();
    }
}

function deleteTask(button) {
    const listItem = button.parentElement.parentElement;
    listItem.remove();
}
